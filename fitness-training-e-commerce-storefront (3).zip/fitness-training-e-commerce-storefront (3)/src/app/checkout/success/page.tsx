import Link from "next/link";
import { CheckCircle } from "lucide-react";

export default function SuccessPage() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-24 text-center">
      <CheckCircle className="h-16 w-16 text-emerald-600 mx-auto mb-6" />
      <h1 className="text-3xl font-extrabold">تم استلام طلبك بنجاح!</h1>
      <p className="mt-3 text-zinc-600">سنقوم بالتواصل معك خلال 24 ساعة لتأكيد التفاصيل وبدء البرنامج.</p>
      <Link href="/" className="inline-block mt-8 px-6 py-3 rounded-xl bg-amber-600 text-white font-bold">العودة للرئيسية</Link>
    </div>
  );
}
