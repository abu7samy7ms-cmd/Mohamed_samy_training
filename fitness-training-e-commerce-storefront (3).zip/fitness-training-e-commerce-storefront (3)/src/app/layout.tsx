import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { CartProvider } from "@/components/CartProvider";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "محمد سامي | تدريب أونلاين للمهتمين بالجيم",
  description: "برامج تدريب أونلاين احترافية لكمال الأجسام، فقدان الوزن، والقوة مع محمد سامي",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-[#fafaf9] text-zinc-900 antialiased selection:bg-amber-200">
        <CartProvider>
          <Header />
          <main className="min-h-[calc(100dvh-200px)]">{children}</main>
          <Footer />
        </CartProvider>
      </body>
    </html>
  );
}
