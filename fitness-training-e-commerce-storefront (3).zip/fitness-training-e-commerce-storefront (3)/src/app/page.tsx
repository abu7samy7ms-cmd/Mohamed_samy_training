import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import Link from "next/link";
import { Star, ArrowLeft } from "lucide-react";
import ProductCard from "@/components/ProductCard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const cats = await db.select().from(categories);
  const featuredProducts = await db.select().from(products).where(eq(products.featured, true)).limit(8);
  const bestSellers = await db.select().from(products).where(eq(products.bestSeller, true)).limit(4);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-[2rem] mt-6 mb-16">
        <div className="absolute inset-0">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="https://images.pexels.com/photos/32830368/pexels-photo-32830368.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=2000" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-l from-black/70 via-black/50 to-transparent" />
        </div>
        <div className="relative z-10 px-8 sm:px-16 py-24 sm:py-32 text-white">
          <div className="max-w-2xl">
            <p className="inline-flex items-center gap-2 rounded-full bg-white/10 backdrop-blur px-4 py-1.5 text-sm border border-white/20">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              تدريب أونلاين مع مدرب معتمد
            </p>
            <h1 className="mt-6 text-[clamp(2.5rem,6vw,4.5rem)] font-extrabold leading-[1.05] tracking-tight">
              ابني جسمك من أي مكان
              <span className="block text-amber-300">مع محمد سامي</span>
            </h1>
            <p className="mt-5 text-lg text-white/80 max-w-xl">
              برامج تدريب وتغذية مخصصة، متابعة أسبوعية، ونتائج مضمونة للمهتمين بالجيم
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/products" className="px-6 py-3 rounded-xl bg-amber-500 text-black font-bold hover:bg-amber-400 transition">
                تصفح البرامج
              </Link>
              <Link href="#collections" className="px-6 py-3 rounded-xl bg-white/10 backdrop-blur border border-white/20 hover:bg-white/20 transition">
                تعرف على المدرب
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Collections / Categories */}
      <section id="collections" className="mb-20">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="text-3xl font-extrabold tracking-tight">التصنيفات المميزة</h2>
            <p className="text-zinc-600 mt-1">اختر هدفك ونبدأ الرحلة معاً</p>
          </div>
          <Link href="/products" className="hidden sm:inline-flex items-center gap-1 text-amber-700 hover:gap-2 transition-all">
            عرض الكل <ArrowLeft className="h-4 w-4" />
          </Link>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {cats.map((cat) => (
            <Link key={cat.id} href={`/products?category=${cat.slug}`} className="group relative rounded-[1.5rem] overflow-hidden aspect-[4/5] bg-zinc-100">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={cat.image || ""} alt="" className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-700" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
              <div className="absolute bottom-0 p-5 text-white">
                <div className="text-sm opacity-80">تصنيف</div>
                <div className="text-xl font-bold">{cat.nameAr}</div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="mb-20">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="text-3xl font-extrabold tracking-tight">برامج مميزة</h2>
            <p className="text-zinc-600 mt-1">أكثر البرامج طلباً ونتائج مثبتة</p>
          </div>
          <Link href="/products" className="hidden sm:inline-flex items-center gap-1 text-amber-700 hover:gap-2 transition-all">
            عرض الكل <ArrowLeft className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Best Sellers */}
      {bestSellers.length > 0 && (
        <section className="mb-24">
          <div className="rounded-[2rem] bg-gradient-to-br from-zinc-900 to-zinc-800 p-10 text-white relative overflow-hidden">
            <div className="absolute -top-20 -right-20 h-64 w-64 rounded-full bg-amber-500/20 blur-3xl" />
            <div className="relative">
              <h3 className="text-2xl font-extrabold">الأكثر مبيعاً</h3>
              <p className="text-white/70 mt-1">اختيارات عملائنا المفضلة</p>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
                {bestSellers.map((p) => (
                  <div key={p.id} className="bg-white/5 backdrop-blur rounded-2xl p-4 border border-white/10">
                    <div className="aspect-[4/3] rounded-xl overflow-hidden bg-zinc-800">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={(p.images as string[])?.[0] || ""} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div className="mt-3 font-semibold leading-tight">{p.titleAr}</div>
                    <div className="text-amber-300 font-bold mt-1">{Number(p.price)} ج.م</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Trust */}
      <section className="mb-24">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { title: "متابعة أسبوعية", desc: "فيديو وتحليل أداء وتعديلات فورية" },
            { title: "برامج مخصصة", desc: "حسب هدفك، مستواك، ووقتك" },
            { title: "نتائج حقيقية", desc: "آلاف العملاء حققوا أهدافهم معنا" },
          ].map((f) => (
            <div key={f.title} className="rounded-2xl border border-zinc-200 p-6 bg-white">
              <div className="text-lg font-bold">{f.title}</div>
              <p className="text-zinc-600 mt-1 text-sm">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
