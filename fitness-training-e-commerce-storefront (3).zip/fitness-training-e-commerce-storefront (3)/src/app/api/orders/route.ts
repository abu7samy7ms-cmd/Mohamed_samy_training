import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { randomUUID } from "crypto";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { customerName, customerEmail, customerPhone, customerAddress, notes, total, items } = body;

    if (!customerName || !customerEmail || !items?.length) {
      return new Response(JSON.stringify({ error: "بيانات ناقصة" }), { status: 400 });
    }

    const orderId = randomUUID();
    await db.insert(orders).values({
      id: orderId,
      customerName,
      customerEmail,
      customerPhone,
      customerAddress,
      notes,
      total: String(total),
      currency: "EGP",
      status: "pending",
    });

    for (const it of items) {
      await db.insert(orderItems).values({
        orderId,
        productId: it.productId,
        productTitleAr: it.productTitleAr,
        productTitleEn: it.productTitleEn || null,
        quantity: it.quantity,
        unitPrice: String(it.unitPrice),
      });
    }

    return new Response(JSON.stringify({ orderId }), { status: 201 });
  } catch (e: any) {
    console.error(e);
    return new Response(JSON.stringify({ error: "فشل إنشاء الطلب" }), { status: 500 });
  }
}
