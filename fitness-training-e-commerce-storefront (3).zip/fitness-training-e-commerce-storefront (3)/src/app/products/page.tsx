import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { eq, ilike, and, desc, asc, sql } from "drizzle-orm";
import Link from "next/link";
import ProductCard from "@/components/ProductCard";

export const dynamic = "force-dynamic";

type SearchParams = { category?: string; search?: string; sort?: string; };

export default async function ProductsPage({ searchParams }: { searchParams?: SearchParams }) {
  const categorySlug = searchParams?.category;
  const search = searchParams?.search?.trim();
  const sort = searchParams?.sort || "newest";

  const cats = await db.select().from(categories);

  // Resolve category id
  let categoryId: number | undefined;
  if (categorySlug) {
    const catRows = await db.select().from(categories).where(eq(categories.slug, categorySlug)).limit(1);
    if (catRows[0]) categoryId = catRows[0].id;
  }

  // Fetch all then filter (small dataset)
  let items = await db.select().from(products);
  if (categoryId) {
    items = items.filter(p => p.categoryId === categoryId);
  }
  if (search) {
    items = items.filter(p => p.titleAr.includes(search));
  }
  switch (sort) {
    case "price_asc":
      items.sort((a,b) => Number(a.price) - Number(b.price));
      break;
    case "price_desc":
      items.sort((a,b) => Number(b.price) - Number(a.price));
      break;
    case "rating":
      items.sort((a,b) => Number(b.ratingAvg || 0) - Number(a.ratingAvg || 0));
      break;
    default:
      items.sort((a,b) => {
        const da = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const db_ = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return db_ - da;
      });
  }

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold">المنتجات</h1>
        <p className="text-zinc-600 mt-1">تصفح برامج التدريب والتغذية</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <aside className="lg:w-64 shrink-0">
          <div className="bg-white rounded-2xl border border-zinc-200 p-5 sticky top-24">
            <form method="get" className="space-y-5">
              <div>
                <label className="text-sm font-semibold">البحث</label>
                <input name="search" defaultValue={search} placeholder="ابحث عن برنامج..." className="mt-1 w-full rounded-xl border border-zinc-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500" />
              </div>
              <div>
                <div className="text-sm font-semibold mb-2">التصنيف</div>
                <div className="space-y-2">
                  <label className="flex items-center gap-2 text-sm">
                    <input type="radio" name="category" value="" defaultChecked={!categorySlug} onChange={() => {}} />
                    الكل
                  </label>
                  {cats.map(c => (
                    <label key={c.id} className="flex items-center gap-2 text-sm">
                      <input type="radio" name="category" value={c.slug} defaultChecked={categorySlug===c.slug} />
                      {c.nameAr}
                    </label>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm font-semibold">الترتيب</label>
                <select name="sort" defaultValue={sort} className="mt-1 w-full rounded-xl border border-zinc-300 px-3 py-2 text-sm">
                  <option value="newest">الأحدث</option>
                  <option value="price_asc">السعر من الأقل للأعلى</option>
                  <option value="price_desc">السعر من الأعلى للأقل</option>
                  <option value="rating">الأعلى تقييماً</option>
                </select>
              </div>
              <button className="w-full py-2 rounded-xl bg-zinc-900 text-white text-sm font-bold">تطبيق</button>
            </form>
          </div>
        </aside>

        <div className="flex-1">
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-zinc-600">{items.length} منتج</p>
          </div>
          {items.length === 0 ? (
            <div className="bg-white rounded-2xl border border-zinc-200 p-12 text-center">
              <p className="text-zinc-600">لا توجد منتجات مطابقة</p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {items.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
