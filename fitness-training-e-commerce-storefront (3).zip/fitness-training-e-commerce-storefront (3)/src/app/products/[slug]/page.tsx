import { db } from "@/db";
import { products, reviews, categories } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Star, Check, Clock, Users, Award } from "lucide-react";
import { useCart } from "@/components/CartProvider";
import AddToCartButton from "@/components/AddToCartButton";
import ImageGallery from "@/components/ImageGallery";

export const dynamic = "force-dynamic";

export default async function ProductDetail({ params }: { params: { slug: string } }) {
  const productRows = await db.select().from(products).where(eq(products.slug, params.slug)).limit(1);
  const product = productRows[0];
  if (!product) notFound();

  const productReviews = await db.select().from(reviews).where(eq(reviews.productId, product.id));
  const category = product.categoryId ? await db.select().from(categories).where(eq(categories.id, product.categoryId)).limit(1).then(r=>r[0]) : null;

  const images = (product.images as string[]) || [];
  const price = Number(product.price);
  const original = product.originalPrice ? Number(product.originalPrice) : null;

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-6 text-sm text-zinc-500">
        <Link href="/">الرئيسية</Link> / <Link href="/products">المنتجات</Link> / <span className="text-zinc-900">{product.titleAr}</span>
      </div>

      <div className="grid lg:grid-cols-2 gap-12">
        <div>
          <ImageGallery images={images} title={product.titleAr} />
          <div className="mt-4 flex gap-2">
            {images.slice(0,4).map((img,i)=>(
              <div key={i} className="w-20 h-20 rounded-xl overflow-hidden bg-zinc-100">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={img} alt="" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center gap-2 text-xs">
            {product.featured && <span className="px-2 py-1 rounded-full bg-amber-100 text-amber-800 font-bold">مميز</span>}
            {product.bestSeller && <span className="px-2 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold">الأكثر مبيعاً</span>}
            {category && <span className="px-2 py-1 rounded-full bg-zinc-100">{category.nameAr}</span>}
          </div>

          <h1 className="mt-3 text-3xl font-extrabold leading-tight">{product.titleAr}</h1>
          <p className="mt-3 text-zinc-600 leading-relaxed">{product.shortDescriptionAr || product.descriptionAr}</p>

          <div className="mt-4 flex items-center gap-3">
            <div className="flex items-center gap-1 text-amber-600">
              {Array.from({length:5}).map((_,i)=>(
                <Star key={i} className={`h-5 w-5 ${i < Math.round(Number(product.ratingAvg||0)) ? 'fill-amber-500' : ''}`} />
              ))}
            </div>
            <span className="text-sm">{Number(product.ratingAvg||0).toFixed(1)} ({product.ratingCount || productReviews.length} تقييم)</span>
          </div>

          <div className="mt-6 flex items-baseline gap-3">
            <span className="text-3xl font-extrabold">{price.toLocaleString()} ج.م</span>
            {original && <span className="text-xl line-through text-zinc-400">{original.toLocaleString()} ج.م</span>}
          </div>

          <AddToCartButton product={product} />

          <div className="mt-8 grid grid-cols-2 gap-3 text-sm">
            {[
              { icon: Clock, label: product.duration || "12 أسبوع" },
              { icon: Users, label: product.level || "جميع المستويات" },
              { icon: Award, label: `${product.sessionsCount || 0} جلسة` },
              { icon: Check, label: "متابعة أسبوعية" },
            ].map((f)=>(
              <div key={f.label} className="flex items-center gap-2 rounded-xl border border-zinc-200 p-3 bg-white">
                <f.icon className="h-4 w-4 text-amber-700" />
                {f.label}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-16 grid lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2">
          <h2 className="text-2xl font-bold mb-4">وصف البرنامج</h2>
          <div className="prose prose-zinc max-w-none">
            <p className="whitespace-pre-wrap">{product.descriptionAr}</p>
          </div>

          <h3 className="text-xl font-bold mt-10 mb-4">التقييمات</h3>
          <div className="space-y-4">
            {productReviews.length === 0 && <p className="text-zinc-500">لا توجد تقييمات بعد.</p>}
            {productReviews.map(r => (
              <div key={r.id} className="rounded-2xl border border-zinc-200 p-4 bg-white">
                <div className="flex items-center gap-2">
                  <div className="font-semibold">{r.authorName}</div>
                  <div className="flex text-amber-500">
                    {Array.from({length:r.rating}).map((_,i)=><Star key={i} className="h-4 w-4 fill-amber-500" />)}
                  </div>
                </div>
                <p className="mt-2 text-zinc-700">{r.commentAr}</p>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="rounded-2xl border border-zinc-200 p-6 bg-white sticky top-24">
            <h4 className="font-bold mb-3">ملخص سريع</h4>
            <ul className="space-y-2 text-sm text-zinc-700">
              <li>• مدة البرنامج: {product.duration || "—"}</li>
              <li>• المستوى: {product.level || "—"}</li>
              <li>• عدد الجلسات: {product.sessionsCount || "—"}</li>
              <li>• متابعة عبر واتساب</li>
              <li>• ضمان استرداد خلال 7 أيام</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
