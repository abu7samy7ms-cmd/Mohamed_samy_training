"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCart } from "./CartProvider";
import CartDrawer from "./CartDrawer";
import { useState } from "react";
import { ShoppingCart, Menu, X, Dumbbell } from "lucide-react";

export default function Header() {
  const [open, setOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const { count } = useCart();
  const pathname = usePathname();

  const nav = [
    { href: "/", label: "الرئيسية" },
    { href: "/products", label: "المنتجات" },
    { href: "#", label: "عن المدرب" },
    { href: "#", label: "تواصل" },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-[#fafaf9]/80 border-b border-zinc-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 grid place-items-center shadow-lg shadow-amber-500/20">
                <Dumbbell className="h-5 w-5 text-white" />
              </div>
              <div className="leading-tight">
                <div className="font-bold tracking-tight text-zinc-900">محمد سامي</div>
                <div className="text-[10px] -mt-1 text-zinc-500">تدريب أونلاين</div>
              </div>
            </Link>

            <nav className="hidden md:flex items-center gap-8">
              {nav.map((n) => (
                <Link
                  key={n.href}
                  href={n.href}
                  className={`text-sm font-medium transition ${
                    pathname === n.href ? "text-amber-700" : "text-zinc-700 hover:text-zinc-900"
                  }`}
                >
                  {n.label}
                </Link>
              ))}
            </nav>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setCartOpen(true)}
                className="relative rounded-full p-2 hover:bg-zinc-100 transition"
                aria-label="السلة"
              >
                <ShoppingCart className="h-5 w-5" />
                {count > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 grid place-items-center rounded-full bg-amber-600 text-white text-[10px] font-bold">
                    {count}
                  </span>
                )}
              </button>
              <button className="md:hidden p-2" onClick={() => setOpen(!open)}>
                {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>
        </div>

        {open && (
          <div className="md:hidden border-t border-zinc-200 bg-white">
            <div className="px-4 py-3 flex flex-col gap-3">
              {nav.map((n) => (
                <Link key={n.href} href={n.href} onClick={() => setOpen(false)} className="py-2 text-sm">
                  {n.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </header>

      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
    </>
  );
}
