"use client";

import Link from "next/link";
import { X, Plus, Minus, Trash2 } from "lucide-react";
import { useCart } from "./CartProvider";
import { useEffect } from "react";

export default function CartDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { items, updateQuantity, removeItem, total, count } = useCart();

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  return (
    <div className={`fixed inset-0 z-50 ${open ? "pointer-events-auto" : "pointer-events-none"}`}>
      <div
        className={`absolute inset-0 bg-black/40 transition-opacity ${open ? "opacity-100" : "opacity-0"}`}
        onClick={onClose}
      />
      <aside
        className={`absolute left-0 top-0 h-full w-full max-w-md bg-white shadow-2xl transition-transform duration-300 ${open ? "translate-x-0" : "-translate-x-full"}`}
        dir="rtl"
      >
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-lg font-bold">السلة ({count})</h2>
          <button onClick={onClose} className="p-2 hover:bg-zinc-100 rounded-full">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex flex-col h-[calc(100%-180px)]">
          <div className="flex-1 overflow-auto p-6 space-y-4">
            {items.length === 0 ? (
              <div className="h-full grid place-items-center text-center">
                <div>
                  <p className="text-zinc-500">السلة فارغة</p>
                  <Link href="/products" onClick={onClose} className="mt-4 inline-block text-amber-700 font-medium">
                    تصفح المنتجات
                  </Link>
                </div>
              </div>
            ) : (
              items.map((item) => (
                <div key={item.productId} className="flex gap-4 p-3 rounded-2xl border border-zinc-200">
                  <div className="h-20 w-20 rounded-xl overflow-hidden bg-zinc-100 flex-shrink-0">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={item.image || "/placeholder.png"} alt="" className="h-full w-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium leading-tight truncate">{item.titleAr}</div>
                    <div className="text-sm text-amber-700 font-bold">{item.price} ج.م</div>
                    <div className="mt-2 flex items-center gap-2">
                      <button onClick={() => updateQuantity(item.productId, item.quantity - 1)} className="p-1 rounded hover:bg-zinc-100">
                        <Minus className="h-4 w-4" />
                      </button>
                      <span className="w-6 text-center text-sm">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.productId, item.quantity + 1)} className="p-1 rounded hover:bg-zinc-100">
                        <Plus className="h-4 w-4" />
                      </button>
                      <button onClick={() => removeItem(item.productId)} className="mr-auto p-1 text-red-600 hover:bg-red-50 rounded">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="p-6 border-t bg-zinc-50">
            <div className="flex items-center justify-between text-sm mb-2">
              <span>المجموع الفرعي</span>
              <span className="font-bold">{total.toFixed(2)} ج.م</span>
            </div>
            <div className="flex items-center justify-between text-sm mb-4 text-zinc-600">
              <span>الشحن</span>
              <span>مجاني</span>
            </div>
            <Link
              href="/checkout"
              onClick={onClose}
              className="w-full block text-center py-3 rounded-xl bg-amber-600 text-white font-bold hover:bg-amber-700 transition"
            >
              متابعة الدفع
            </Link>
          </div>
        </div>
      </aside>
    </div>
  );
}
