import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-zinc-200 bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="font-bold text-lg">محمد سامي</div>
            <p className="mt-2 text-sm text-zinc-600 leading-relaxed">
              تدريب أونلاين احترافي للمهتمين بالجيم. برامج مخصصة، متابعة دقيقة، ونتائج حقيقية.
            </p>
          </div>
          <div>
            <div className="font-semibold mb-3">روابط سريعة</div>
            <ul className="space-y-2 text-sm text-zinc-600">
              <li><Link href="/">الرئيسية</Link></li>
              <li><Link href="/products">المنتجات</Link></li>
              <li><Link href="#">الأسئلة الشائعة</Link></li>
            </ul>
          </div>
          <div>
            <div className="font-semibold mb-3">التصنيفات</div>
            <ul className="space-y-2 text-sm text-zinc-600">
              <li>كمال الأجسام</li>
              <li>فقدان الوزن</li>
              <li>القوة والرفع</li>
              <li>التغذية الرياضية</li>
            </ul>
          </div>
          <div>
            <div className="font-semibold mb-3">تواصل معنا</div>
            <p className="text-sm text-zinc-600">واتساب: +20 100 000 0000</p>
            <p className="text-sm text-zinc-600">البريد: contact@mohamedsamy.fit</p>
          </div>
        </div>
        <div className="mt-10 pt-6 border-t text-center text-xs text-zinc-500">
          © {new Date().getFullYear()} محمد سامي - جميع الحقوق محفوظة
        </div>
      </div>
    </footer>
  );
}
