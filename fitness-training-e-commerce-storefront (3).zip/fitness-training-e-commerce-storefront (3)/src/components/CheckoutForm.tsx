"use client";

import { useCart } from "./CartProvider";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function CheckoutForm() {
  const { items, total, clear } = useCart();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    if (items.length === 0) {
      setError("السلة فارغة");
      return;
    }
    setLoading(true);
    const form = new FormData(e.currentTarget);
    const payload = {
      customerName: form.get("name"),
      customerEmail: form.get("email"),
      customerPhone: form.get("phone"),
      customerAddress: form.get("address"),
      notes: form.get("notes"),
      total: total,
      items: items.map(i => ({
        productId: i.productId,
        productTitleAr: i.titleAr,
        quantity: i.quantity,
        unitPrice: i.price,
      })),
    };

    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("فشل الإنشاء");
      clear();
      router.push("/checkout/success");
    } catch (err: any) {
      setError(err.message || "حدث خطأ");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid lg:grid-cols-3 gap-8">
      <form onSubmit={handleSubmit} className="lg:col-span-2 bg-white rounded-2xl border border-zinc-200 p-6 space-y-4">
        <h2 className="text-xl font-bold">بيانات العميل</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="text-sm">الاسم الكامل</label>
            <input name="name" required className="mt-1 w-full rounded-xl border border-zinc-300 px-3 py-2" />
          </div>
          <div>
            <label className="text-sm">البريد الإلكتروني</label>
            <input name="email" type="email" required className="mt-1 w-full rounded-xl border border-zinc-300 px-3 py-2" />
          </div>
          <div>
            <label className="text-sm">رقم الهاتف</label>
            <input name="phone" required className="mt-1 w-full rounded-xl border border-zinc-300 px-3 py-2" />
          </div>
          <div>
            <label className="text-sm">العنوان</label>
            <input name="address" className="mt-1 w-full rounded-xl border border-zinc-300 px-3 py-2" />
          </div>
        </div>
        <div>
          <label className="text-sm">ملاحظات</label>
          <textarea name="notes" rows={3} className="mt-1 w-full rounded-xl border border-zinc-300 px-3 py-2" />
        </div>
        {error && <p className="text-red-600 text-sm">{error}</p>}
        <button disabled={loading} className="w-full py-3 rounded-xl bg-zinc-900 text-white font-bold disabled:opacity-60">
          {loading ? "جاري المعالجة..." : "تأكيد الطلب"}
        </button>
      </form>

      <div className="bg-white rounded-2xl border border-zinc-200 p-6 h-fit">
        <h3 className="font-bold text-lg mb-4">ملخص الطلب</h3>
        <div className="space-y-3 max-h-64 overflow-auto">
          {items.map(i=>(
            <div key={i.productId} className="flex justify-between text-sm">
              <span className="truncate">{i.titleAr} × {i.quantity}</span>
              <span>{(i.price*i.quantity).toFixed(0)} ج.م</span>
            </div>
          ))}
        </div>
        <div className="border-t mt-4 pt-4 flex justify-between font-bold">
          <span>المجموع</span>
          <span>{total.toFixed(2)} ج.م</span>
        </div>
      </div>
    </div>
  );
}
