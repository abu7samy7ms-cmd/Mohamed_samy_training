"use client";

import { useState } from "react";

export default function ImageGallery({ images, title }: { images: string[]; title: string }) {
  const [idx, setIdx] = useState(0);
  const safe = images.length ? images : ["https://images.pexels.com/photos/32830368/pexels-photo-32830368.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200"];
  return (
    <div className="rounded-[1.5rem] overflow-hidden bg-zinc-100">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={safe[idx]} alt={title} className="w-full aspect-[4/3] object-cover" />
      <div className="flex gap-2 p-3 bg-white">
        {safe.map((img,i)=>(
          <button key={i} onClick={()=>setIdx(i)} className={`w-16 h-16 rounded-lg overflow-hidden border-2 ${i===idx?'border-amber-600':'border-transparent'}`}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img} alt="" className="w-full h-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
}
