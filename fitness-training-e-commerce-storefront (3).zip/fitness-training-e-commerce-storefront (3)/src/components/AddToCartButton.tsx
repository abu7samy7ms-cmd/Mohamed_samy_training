"use client";

import { useCart } from "./CartProvider";
import { Product } from "@/db/schema";
import { ShoppingCart } from "lucide-react";
import { useState } from "react";

export default function AddToCartButton({ product }: { product: Product }) {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  const images = (product.images as string[]) || [];
  const price = Number(product.price);

  const handleAdd = () => {
    addItem({
      productId: product.id,
      titleAr: product.titleAr,
      price,
      image: images[0],
      slug: product.slug,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <button
      onClick={handleAdd}
      className="mt-6 w-full py-3.5 rounded-xl bg-amber-600 text-white font-bold text-lg hover:bg-amber-700 transition flex items-center justify-center gap-2"
    >
      <ShoppingCart className="h-5 w-5" />
      {added ? "تم الإضافة!" : "أضف إلى السلة"}
    </button>
  );
}
