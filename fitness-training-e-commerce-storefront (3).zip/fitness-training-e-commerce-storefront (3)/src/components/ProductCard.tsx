import Link from "next/link";
import { Star } from "lucide-react";
import { Product } from "@/db/schema";
import { useCart } from "./CartProvider";

type Props = { product: Product };

export default function ProductCard({ product }: Props) {
  const images = (product.images as string[]) || [];
  const price = Number(product.price);
  const original = product.originalPrice ? Number(product.originalPrice) : null;
  const discount = original ? Math.round((1 - price / original) * 100) : 0;

  return (
    <Link href={`/products/${product.slug}`} className="group block">
      <div className="rounded-[1.5rem] overflow-hidden bg-white border border-zinc-200 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
        <div className="relative aspect-[4/3] overflow-hidden bg-zinc-100">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={images[0] || ""} alt={product.titleAr} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" />
          {product.featured && (
            <span className="absolute top-3 right-3 bg-amber-500 text-black text-xs font-bold px-2.5 py-1 rounded-full">مميز</span>
          )}
          {discount > 0 && (
            <span className="absolute top-3 left-3 bg-red-600 text-white text-xs font-bold px-2.5 py-1 rounded-full">-{discount}%</span>
          )}
        </div>
        <div className="p-4">
          <div className="text-[11px] uppercase tracking-wide text-zinc-500">{product.duration || "برنامج"}</div>
          <h3 className="mt-1 font-bold leading-snug line-clamp-2">{product.titleAr}</h3>
          <div className="mt-2 flex items-center gap-2">
            <div className="flex items-center gap-1 text-amber-600">
              <Star className="h-4 w-4 fill-amber-500" />
              <span className="text-sm font-semibold">{Number(product.ratingAvg || 0).toFixed(1)}</span>
            </div>
            <span className="text-xs text-zinc-500">({product.ratingCount || 0})</span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-lg font-extrabold text-zinc-900">{price.toLocaleString()} ج.م</span>
            {original && <span className="text-sm line-through text-zinc-400">{original.toLocaleString()} ج.م</span>}
          </div>
        </div>
      </div>
    </Link>
  );
}
