import { pgTable, serial, text, integer, numeric, boolean, timestamp, uuid, jsonb, decimal } from "drizzle-orm/pg-core";

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en"),
  slug: text("slug").notNull().unique(),
  descriptionAr: text("description_ar"),
  descriptionEn: text("description_en"),
  image: text("image"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  titleAr: text("title_ar").notNull(),
  titleEn: text("title_en"),
  slug: text("slug").notNull().unique(),
  descriptionAr: text("description_ar"),
  descriptionEn: text("description_en"),
  shortDescriptionAr: text("short_description_ar"),
  shortDescriptionEn: text("short_description_en"),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  originalPrice: numeric("original_price", { precision: 10, scale: 2 }),
  currency: text("currency").default("EGP"),
  images: jsonb("images").$type<string[]>(),
  categoryId: integer("category_id").references(() => categories.id),
  tags: text("tags").array(),
  featured: boolean("featured").default(false),
  bestSeller: boolean("best_seller").default(false),
  duration: text("duration"),
  level: text("level"),
  sessionsCount: integer("sessions_count"),
  stock: integer("stock").default(999),
  ratingAvg: numeric("rating_avg", { precision: 3, scale: 2 }).default("0"),
  ratingCount: integer("rating_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id, { onDelete: "cascade" }).notNull(),
  authorName: text("author_name").notNull(),
  authorAvatar: text("author_avatar"),
  rating: integer("rating").notNull(),
  commentAr: text("comment_ar"),
  commentEn: text("comment_en"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orders = pgTable("orders", {
  id: uuid("id").defaultRandom().primaryKey(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone"),
  customerAddress: text("customer_address"),
  total: numeric("total", { precision: 12, scale: 2 }).notNull(),
  currency: text("currency").default("EGP"),
  status: text("status").default("pending"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: uuid("order_id").references(() => orders.id, { onDelete: "cascade" }).notNull(),
  productId: integer("product_id").references(() => products.id).notNull(),
  productTitleAr: text("product_title_ar").notNull(),
  productTitleEn: text("product_title_en"),
  quantity: integer("quantity").notNull().default(1),
  unitPrice: numeric("unit_price", { precision: 10, scale: 2 }).notNull(),
});

export type Category = typeof categories.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type OrderItem = typeof orderItems.$inferSelect;
