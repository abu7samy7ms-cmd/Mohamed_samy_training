import { db } from "./db";
import { categories, products, reviews } from "./db/schema";
import { eq } from "drizzle-orm";

async function seed() {
  // Clear existing
  await db.delete(reviews);
  await db.delete(products);
  await db.delete(categories);

  const [cat1, cat2, cat3, cat4] = await db.insert(categories).values([
    {
      nameAr: "كمال الأجسام",
      nameEn: "Bodybuilding",
      slug: "bodybuilding",
      descriptionAr: "برامج تدريب مكثفة لبناء العضلات والقوة",
      image: "https://images.pexels.com/photos/32830368/pexels-photo-32830368.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    },
    {
      nameAr: "فقدان الوزن",
      nameEn: "Fat Loss",
      slug: "fat-loss",
      descriptionAr: "برامج اونلاين لحرق الدهون وشد الجسم",
      image: "https://images.pexels.com/photos/6392833/pexels-photo-6392833.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    },
    {
      nameAr: "القوة والرفع",
      nameEn: "Strength & Powerlifting",
      slug: "strength",
      descriptionAr: "تدريب متقدم للرفع والقوة الوظيفية",
      image: "https://images.pexels.com/photos/4853332/pexels-photo-4853332.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    },
    {
      nameAr: "التغذية الرياضية",
      nameEn: "Sports Nutrition",
      slug: "nutrition",
      descriptionAr: "خطط غذائية مخصصة لتحقيق أهدافك",
      image: "https://images.pexels.com/photos/29703809/pexels-photo-29703809.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    },
  ]).returning();

  const productData = [
    {
      titleAr: "برنامج تدريب كمال أجسام مبتدئ 12 أسبوع",
      titleEn: "12-Week Beginner Bodybuilding Program",
      slug: "beginner-bodybuilding-12-week",
      shortDescriptionAr: "برنامج اونلاين شامل مع متابعة أسبوعية",
      descriptionAr: "برنامج تدريب كامل لمدة 12 أسبوع مصمم للمبتدئين لبناء كتلة عضلية نظيفة مع متابعة أسبوعية عبر فيديو وتعديلات على الوجبات. يتضمن جدول تمارين، نظام غذائي، وتقييم تقدم شهري.",
      price: "1499",
      originalPrice: "1999",
      images: [
        "https://images.pexels.com/photos/32830368/pexels-photo-32830368.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
        "https://images.pexels.com/photos/15679570/pexels-photo-15679570.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
      ],
      categoryId: cat1.id,
      tags: ["مبتدئ", "كمال أجسام", "اونلاين"],
      featured: true,
      bestSeller: true,
      duration: "12 أسبوع",
      level: "مبتدئ",
      sessionsCount: 36,
    },
    {
      titleAr: "تحدي حرق الدهون 8 أسابيع - تدريب اونلاين",
      titleEn: "8-Week Fat Burn Challenge",
      slug: "fat-burn-8-weeks",
      shortDescriptionAr: "خطة متكاملة لحرق الدهون مع دعم تغذية",
      descriptionAr: "برنامج مكثف 8 أسابيع لحرق الدهون وزيادة معدل الأيض مع تدريبات HIIT وقوة، متابعة يومية عبر تطبيقات التواصل، وخطة غذائية مرنة.",
      price: "1299",
      originalPrice: "1799",
      images: [
        "https://images.pexels.com/photos/6392833/pexels-photo-6392833.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
        "https://images.pexels.com/photos/38755282/pexels-photo-38755282.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
      ],
      categoryId: cat2.id,
      tags: ["حرق دهون", "HIIT", "تغذية"],
      featured: true,
      duration: "8 أسابيع",
      level: "جميع المستويات",
      sessionsCount: 24,
    },
    {
      titleAr: "برنامج قوة متقدم للرفع التقني",
      titleEn: "Advanced Strength & Technique Program",
      slug: "advanced-strength-technique",
      shortDescriptionAr: "للاعبين المتقدمين لتحسين الأداء",
      descriptionAr: "برنامج 16 أسبوع يركز على تقنية الرفع، زيادة الأوزان القصوى، وتقوية نقاط الضعف مع تحليل فيديو لكل تمرين.",
      price: "2199",
      images: [
        "https://images.pexels.com/photos/4853332/pexels-photo-4853332.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
        "https://images.pexels.com/photos/4853339/pexels-photo-4853339.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
      ],
      categoryId: cat3.id,
      tags: ["قوة", "رفع", "متقدم"],
      featured: false,
      bestSeller: true,
      duration: "16 أسبوع",
      level: "متقدم",
      sessionsCount: 48,
    },
    {
      titleAr: "خطة تغذية رياضية مخصصة 3 أشهر",
      titleEn: "3-Month Custom Sports Nutrition Plan",
      slug: "custom-nutrition-3-month",
      shortDescriptionAr: "قائمة طعام يومية مع متابعة مستمرة",
      descriptionAr: "خطة غذائية مخصصة بالكامل حسب هدفك (تضخيم/تنشيف) مع وجبات مصرية متوفرة، متابعة أسبوعية للتعديلات، ودعم عبر واتساب.",
      price: "999",
      originalPrice: "1399",
      images: [
        "https://images.pexels.com/photos/29703809/pexels-photo-29703809.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
        "https://images.pexels.com/photos/32695899/pexels-photo-32695899.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
      ],
      categoryId: cat4.id,
      tags: ["تغذية", "خطة غذائية"],
      featured: true,
      duration: "3 أشهر",
      level: "جميع المستويات",
    },
    {
      titleAr: "برنامج تحضير بطولة كمال أجسام 20 أسبوع",
      titleEn: "20-Week Bodybuilding Contest Prep",
      slug: "contest-prep-20-week",
      shortDescriptionAr: "تحضير احترافي للبطولات مع متابعة دقيقة",
      descriptionAr: "برنامج تحضير بطولة كامل يتضمن تدريب، تغذية، كارديو، و Peak Week مع متابعة يومية وتعديلات فورية.",
      price: "3499",
      images: [
        "https://images.pexels.com/photos/16966301/pexels-photo-16966301.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
        "https://images.pexels.com/photos/31255961/pexels-photo-31255961.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
      ],
      categoryId: cat1.id,
      tags: ["بطولة", "تحضير", "احترافي"],
      featured: false,
      duration: "20 أسبوع",
      level: "احترافي",
      sessionsCount: 60,
    },
    {
      titleAr: "تدريب اونلاين نسائي خاص - فتنس وتشكيل",
      titleEn: "Women's Online Fitness & Shaping",
      slug: "women-online-fitness",
      shortDescriptionAr: "برنامج آمن وفعال للسيدات",
      descriptionAr: "برنامج تدريب اونلاين مخصص للسيدات لشد الجسم وبناء اللياقة مع تمارين مناسبة في المنزل أو الجيم مع متابعة خاصة.",
      price: "1099",
      images: [
        "https://images.pexels.com/photos/6392833/pexels-photo-6392833.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
        "https://images.pexels.com/photos/15679570/pexels-photo-15679570.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
      ],
      categoryId: cat2.id,
      tags: ["نسائي", "تشكيل"],
      featured: true,
      duration: "12 أسبوع",
      level: "مبتدئ",
      sessionsCount: 36,
    },
  ];

  const insertedProducts = await db.insert(products).values(productData).returning();

  // Reviews
  const reviewData = [
    { productId: insertedProducts[0].id, authorName: "أحمد م.", rating: 5, commentAr: "برنامج ممتاز والمتابعة مذهلة، زدت 4 كيلو عضل في 12 أسبوع" },
    { productId: insertedProducts[0].id, authorName: "محمود ع.", rating: 5, commentAr: "محمد سامي محترف جداً، البرنامج منظم والتعديلات سريعة" },
    { productId: insertedProducts[1].id, authorName: "سارة ك.", rating: 5, commentAr: "نزلت 8 كيلو دهون في 8 أسابيع، التغذية كانت مفتاح النجاح" },
    { productId: insertedProducts[1].id, authorName: "علي ر.", rating: 4, commentAr: "تمارين قوية ومناسبة للوقت" },
    { productId: insertedProducts[2].id, authorName: "كريم ص.", rating: 5, commentAr: "أدائي في الرفعة المميتة تحسن بشكل كبير" },
    { productId: insertedProducts[3].id, authorName: "منى ف.", rating: 5, commentAr: "الخطة الغذائية سهلة التطبيق والمذاق رائع" },
    { productId: insertedProducts[4].id, authorName: "يوسف ح.", rating: 5, commentAr: "تحضير البطولة كان احترافي 100%" },
    { productId: insertedProducts[5].id, authorName: "نورا س.", rating: 5, commentAr: "أخيراً برنامج يناسب جدول البيت" },
  ];

  await db.insert(reviews).values(reviewData);

  // Update rating avg
  for (const p of insertedProducts) {
    const revs = await db.select().from(reviews).where(eq(reviews.productId, p.id));
    if (revs.length > 0) {
      const avg = revs.reduce((a, b) => a + b.rating, 0) / revs.length;
      await db.update(products).set({ ratingAvg: avg.toFixed(2), ratingCount: revs.length }).where(eq(products.id, p.id));
    }
  }

  console.log("Seed completed");
}

seed().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
